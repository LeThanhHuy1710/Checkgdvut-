function hidePopup() {
  document.getElementById('popup').style.display = 'none';
}
